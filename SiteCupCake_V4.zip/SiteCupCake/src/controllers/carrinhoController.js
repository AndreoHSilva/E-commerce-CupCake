const { Carrinho } = require('../models/CarrinhoModel'); 
const Produto = require('../models/ProdutoModel'); 

exports.index = async (req, res) => {
    const user = req.session.user || null; 
    let produtos = [];

    if (user) {
        produtos = await Carrinho.buscaProdutos(user._id); 
    }

    res.render('carrinho', { user, produtos });     
};

exports.adicionarAoCarrinho = async (req, res) => {
    try {
        const produtoId = req.params.id;
        console.log(produtoId);
        const userId = req.session.user._id;
        const quantidade = parseInt(req.body.quantidade, 10);

        const produto = await Produto.buscaPorId(produtoId);
        if (!produto) {
            req.flash('errors', ['Produto não encontrado.']);
            return res.redirect('back');
        }

        const carrinho = new Carrinho();
        const mensagem = await carrinho.adicionaItemCarrinho(produtoId, produto.nomeProduto, produto.preco, userId, quantidade);
        
        if(mensagem === 'adicionado') {
            req.flash('success', 'Produto adicionado ao carrinho com sucesso.');
        } else {
            req.flash('errors', ['Produto já está no carrinho.']);
        }
        
        res.redirect('/carrinho/index'); 
        
    } catch (e) {
        console.log(e);
        req.flash('errors', ['Erro ao adicionar produto ao carrinho.']);
        res.redirect('back');
    }
};

exports.atualizarQuantidade = async(req, res) => {
    try {
        const produtoId = req.params.id;
        const userId = req.session.user._id;
        const novaQuantidade = parseInt(req.body.quantidade, 10);

        const carrinho = new Carrinho();
        const mensagem = await carrinho.atualizaQuantidade(produtoId, userId, novaQuantidade);
        
        if (mensagem === 'atualizado') {
            req.flash('success', 'Quantidade atualizada com sucesso.');
        } else {
            req.flash('errors', ['Produto não encontrado no carrinho.']);
        }
        
        res.redirect('/carrinho/index');
        
    } catch (e) {
        console.log(e);
        req.flash('errors', ['Erro ao atualizar quantidade no carrinho.']);
        res.redirect('back');
    }
};

exports.removerDoCarrinho = async (req, res) => {
    try {
        const produtoId = req.params.id; 
        const userId = req.session.user._id; 

        const carrinho = new Carrinho();
        await carrinho.removeItemCarrinho(produtoId, userId);

        req.flash('success', 'Produto removido do carrinho com sucesso.');
        res.redirect('/carrinho/index'); 
    } catch (e) {
        console.log(e);
        req.flash('errors', ['Erro ao remover produto do carrinho.']);
        res.redirect('back');
    }
};

// boleto vai pegar o valor total de todos os produtos e gerar o pagamento, se o pagamento for sucedido os itens do carrinho vai ser zerado
exports.gerarBoleto = async (req, res) => {

};