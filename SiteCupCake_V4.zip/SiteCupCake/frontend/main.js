import './assets/css/style.css';
import 'regenerator-runtime/runtime';

import 'core-js/stable';

