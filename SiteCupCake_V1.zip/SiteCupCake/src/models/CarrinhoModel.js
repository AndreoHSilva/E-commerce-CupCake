const mongoose = require('mongoose');
const validator = require('validator');

const CarrinhoSchema = new mongoose.Schema({
    nomeProduto: {type: String, require: true},
    preco: {type: String, require: true},
    produto: {type: String, require: true},
});

const CarrinhoModel = mongoose.model('Carrinho', CarrinhoSchema);

function Carrinho (body) {
    this.body = body;
    this.errors = [];
    this.produto = null;
}

Carrinho.prototype.register = async function(){
    this.valida();
    if(this.errors.length > 0) return;
    this.carrinho = await CarrinhoModel.create(this.body);
};

Carrinho.prototype.valida = function(){
    // Validação 
    this.cleanUP();
    // O
    if(!this.body.nomeProduto) this.errors.push('Nome do produto é um campo obrigatório.');
    if(!this.body.preco) this.errors.push('O preço do produto é um campo obrigatório.');
    if(!this.body.produto) this.errors.push('Produto é um campo obrigatório.');
    if(!this.body.nomeProduto || !this.body.preco || !this.body.produto){ 
        this.errors.push('Os campos: Nome do Produto, preço e produto são obrigatórios.');
    };
}

Carrinho.prototype.cleanUP = function(){
    for(const key in this.body){
        if(typeof this.body[key] !== 'string'){
            this.body[key] = '';
        }
    }

    this.body = {
        nomeProduto: this.body.nomeProduto,  
        preco: this.body.preco, 
        categoria: this.body.categoria,
        igredientes: this.body.igredientes,
        produto: this.body.produto,
        criadoEm: Date.now(),
    };
}

// Metodos estáticos 
Carrinho.buscaPorId = async function(id){
    if(typeof id !== 'string') return;
    const produto = await ProdutoModel.findById(id);
    return produto;
};

Carrinho.buscaProdutos = async function(){
    const produtos = await CarrinhoModel.find()
        .sort({criadoEm: -1});
    return produtos;
};

Carrinho.delete = async function(id){
    if(typeof id !== 'string') return;
    const produto = await ProdutoModel.findOneAndDelete({_id: id});
    return produto;
}; 

module.exports = Carrinho;
