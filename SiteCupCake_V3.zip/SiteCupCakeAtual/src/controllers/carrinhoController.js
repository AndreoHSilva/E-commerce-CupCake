const Carrinho = require('../models/CarrinhoModel');

exports.index = async (req, res) => {
    const produtos = await Carrinho.buscaProdutos();
    res.render('carrinho', { produtos });
};

exports.register = async (req, res) => {
    try{
        const produto = new Produto(req.body);
        await produto.register();
    
        if(produto.errors.length > 0){
            req.flash('errors', produto.errors);
            req.session.save(() => res.redirect('back'));
            return;
        }

        req.flash('success', 'Produto registrado com sucesso.');
        req.session.save(() => res.redirect(`/cadastro-produto/index/${produto.produto._id}`));
        return;
    }catch(e){
        console.log(e);
        return res.render('404');
    }
};

